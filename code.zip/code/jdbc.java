
import java.sql.Driver;
public class JDBCTest01
{
	try{
		//1.ע������
		Driver driver=new com.
	}catch(SQLExcaption e){
		s.printStackTrace();
	}
}